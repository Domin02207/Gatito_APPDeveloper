package com.example.myapplication;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recommendedRecyclerView;
    private RecommendedAdapter recommendedAdapter;
    private List<Product> productList;

    @Override
    protected void onCreate(int savedInstanceState) {
        super.onCreate(savedInstanceState);
        onCreate(R.layout.item_recommended);

        recommendedRecyclerView = recommendedRecyclerView.findViewById();
        recommendedRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        // Inicializar a lista de produtos
        productList = new ArrayList<>();
        productList.add(new Product("Hill's para Cães Filhotes", "R$ 52,99", R.drawable.product_image));
        productList.add(new Product("Ração Hill's Science Diet", "R$ 479,99", R.drawable.product_image));
        // Adicione mais produtos conforme necessário

        recommendedAdapter = new RecommendedAdapter(productList);
        recommendedRecyclerView.setAdapter(recommendedAdapter);
    }
}
