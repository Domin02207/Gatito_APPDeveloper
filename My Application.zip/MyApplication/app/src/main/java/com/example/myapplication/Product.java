package com.example.myapplication;

public class Product {
    private String name;
    private String price;
    private int imageUrl;

    public Product(String name, String price, int imageUrl) {
        this.name = name;
        this.price = price;
        this.imageUrl = imageUrl;
    }

    public String getName() {
        return name;
    }

    public String getPrice() {
        return price;
    }

    public int getImageUrl() {
        return imageUrl;
    }
}
