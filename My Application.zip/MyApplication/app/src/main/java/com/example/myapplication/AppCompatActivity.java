package com.example.myapplication;

public class AppCompatActivity {
    protected void onCreate(int savedInstanceState) {
    }
}
