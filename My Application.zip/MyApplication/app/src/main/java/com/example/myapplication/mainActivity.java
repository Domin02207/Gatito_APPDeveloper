package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class mainActivity extends AppCompatActivity {

    private EditText etCpf;
    private EditText etPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etCpf = findViewById(R.id.etCpf);
        etPassword = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);
        TextView tvForgotPassword = findViewById(R.id.tvForgotPassword);
        TextView tvRegister = findViewById(R.id.tvRegister);

        btnLogin.setOnClickListener(view -> {
            // Handle login logic
            String cpf = etCpf.getText().toString();
            String password = etPassword.getText().toString();

            if(cpf.isEmpty() || password.isEmpty()) {
                Toast.makeText(mainActivity.this, "Por favor, preencha todos os campos", Toast.LENGTH_SHORT).show();
            } else {
                // Perform login action
                Toast.makeText(mainActivity.this, "Login realizado com sucesso", Toast.LENGTH_SHORT).show();
            }
        });

        tvForgotPassword.setOnClickListener(view -> {
            // Handle forgot password logic
            Toast.makeText(mainActivity.this, "Esqueceu a senha clicado", Toast.LENGTH_SHORT).show();
        });

        tvRegister.setOnClickListener(view -> {
            // Handle register logic
            Toast.makeText(mainActivity.this, "Cadastro clicado", Toast.LENGTH_SHORT).show();
        });
    }
}
